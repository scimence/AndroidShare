﻿
package com.sc.androidshare;

import java.io.File;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.sci.androidshare.R;


public class MainActivity extends Activity
{
	/** 选择分享视屏 */
	public void shareVideo()
	{
		selectFile(this, "video/*", true);
	}
	
	/** 选择分享图片 */
	public void shareImage()
	{
		selectFile(this, "image/*", true);
	}
	
	/** 选择分享音频 */
	public void shareAudio()
	{
		selectFile(this, "audio/*", true);
	}
	
	/** 分享文本信息 */
	public void shareMSG(String msg)
	{
		ShareMSG(this, "分享文本：" + msg);
	}
	
	/** 选择分享文件 */
	public void shareFile()
	{
		selectFile(this, "*/*", true);
	}
	
	/** 分享指定（路径、类型）的文件 */
	public void shareFile(String filePath, String fileType)
	{
		File file = new File(filePath);
		if (file.exists())
		{
			Uri uri = Uri.fromFile(file);
			shareFile(this, uri, fileType);
		}
	}
	
	// --------------
	
	EditText text = null;
	
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		text = (EditText) this.findViewById(R.id.textView1);
	}
	
	public void Button_Click(View view)
	{
		String msg = text.getText().toString();
		shareMSG("分享文本：" + msg);
	}
	
	public void Button_Click2(View view)
	{
		shareFile();
	}
	
	public void Button_Click3(View view)
	{
		shareVideo();
	}
	
	public void Button_Click4(View view)
	{
		shareAudio();
	}
	
	public void Button_Click5(View view)
	{
		shareImage();
	}
	
	/** 调用系统方法选择文件 */
	private void selectFile(Activity context, String type, boolean autoShare)
	{
		Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
		intent.setType(type);								// 设置类型，我这里是任意类型，任意后缀的可以这样写。
		intent.addCategory(Intent.CATEGORY_OPENABLE);
		
		if (autoShare)
			context.startActivityForResult(intent, SELECT);
		else context.startActivityForResult(intent, SELECT_ONLY);
	}
	
	final static int SELECT_ONLY = 3;	// 标记选取
	final static int SELECT = 1;	// 标记选取
	final static int SHARE = 2;		// 标记分享
	
	/** Activity执行结果 */
	protected void onActivityResult(int requestCode, int resultCode, Intent data)
	{
		if (resultCode == Activity.RESULT_OK)
		{
			if (requestCode == SELECT)
			{
				Uri uri = data.getData();
				// String fileType = data.getType();
				String fileType = getType(uri);
				shareFile(this, uri, fileType);
				
				Toast.makeText(this, "分享文件：" + uri.getPath().toString(), Toast.LENGTH_SHORT).show();
			}
			else if (requestCode == SHARE)
			{
				ShareSuccess();
			}
		}
	}
	
	/** 获取uri对应的文件类型 */
	private String getType(Uri uri)
	{
		String uriPath = uri.getPath().toString();	// "/document/image:57329"
		int start = uriPath.lastIndexOf("/");
		int end = uriPath.lastIndexOf(":");
		
		String type = "*/*";
		if (end > start)
		{
			type = uriPath.substring(start + 1, end) + "/*";
		}
		return type;
	}
	
	/** 分享完成逻辑 */
	public void ShareSuccess()
	{
		Toast.makeText(this, "分享完成！", Toast.LENGTH_SHORT).show();
	}
	
	// ----------------
	
	/** 调用系統方法分享字符串消息 */
	public static void ShareMSG(Activity context, String msg)
	{
		Intent shareInt = new Intent(Intent.ACTION_SEND);
		// shareInt.setPackage("com.tencent.mm"); // 分享到微信
		
		shareInt.setType("text/plain");
		shareInt.putExtra(Intent.EXTRA_SUBJECT, "选择分享方式");
		shareInt.putExtra(Intent.EXTRA_TEXT, msg);              // 要分享的内容
		shareInt.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		
		// context.startActivity(Intent.createChooser(shareInt, "分享给"));
		context.startActivityForResult(Intent.createChooser(shareInt, "分享给"), 2);
	}
	
	/** 调用系統方法, 分享文件 */
	public static void shareFile(Activity context, Uri fileUri, String type)
	{
		if (fileUri != null)
		{
			Intent shareInt = new Intent(Intent.ACTION_SEND);
			shareInt.putExtra(Intent.EXTRA_STREAM, fileUri);
			
			Toast.makeText(context, "分享文件类型：" + type, Toast.LENGTH_SHORT).show();
			shareInt.setType(type);			// 文件类型
			
			// intent.setType("*/*");
			// intent.setType("image/*");//选择图片
			// intent.setType("audio/*"); //选择音频
			// intent.setType("video/*"); //选择视频 （mp4 3gp 是android支持的视频格式）
			// intent.setType("video/*;image/*");//同时选择视频和图片
			
			shareInt.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			shareInt.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
			
			context.startActivity(Intent.createChooser(shareInt, "分享给"));
			// context.startActivityForResult(Intent.createChooser(shareInt, "分享给"), 2);
		}
		else
		{
			Toast.makeText(context, "分享文件不存在", Toast.LENGTH_SHORT).show();
		}
	}
	
	// public void ShareFile(String filePath)
	// {
	// ArrayList<Uri> files = new ArrayList<Uri>();
	// files.add(Uri.fromFile(new File(filePath)));
	//
	// // 分享文件
	// Intent intent = new Intent(Intent.ACTION_SEND_MULTIPLE);// 发送多个文件
	// intent.setType("*/*"); // 多个文件格式
	// intent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, files);// Intent.EXTRA_STREAM同于传输文件流
	// startActivity(intent);
	// }
	
	/** 调用系統方法分享video */
	public static void ShareVideo(Activity context, Uri fileUri)
	{
		shareFile(context, fileUri, "video/*");
	}
	
	/** 调用系統方法分享image */
	public static void ShareImage(Activity context, Uri fileUri)
	{
		shareFile(context, fileUri, "image/*");
	}
	
	/** 调用系統方法分享audio */
	public static void ShareAudio(Activity context, Uri fileUri)
	{
		shareFile(context, fileUri, "audio/*");
	}
	
	/** 调用系統方法任意其他类型文件 */
	public static void Share(Activity context, Uri fileUri)
	{
		shareFile(context, fileUri, "*/*");
	}
	
	// 調用系統方法分享文件
	public static void shareVedioFile(Activity context, File file)
	{
		shareFile(context, Uri.fromFile(file), "video/*");
	}
	
//	// 根据文件后缀名获得对应的MIME类型。
//	private static String getMimeType(String filePath)
//	{
//		MediaMetadataRetriever mmr = new MediaMetadataRetriever();
//		String mime = "*/*";
//		if (filePath != null)
//		{
//			try
//			{
//				mmr.setDataSource(filePath);
//				mime = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_MIMETYPE);
//			}
//			catch (IllegalStateException e)
//			{
//				return mime;
//			}
//			catch (IllegalArgumentException e)
//			{
//				return mime;
//			}
//			catch (RuntimeException e)
//			{
//				return mime;
//			}
//		}
//		return mime;
//	}
}
